from serpapi import GoogleSearch
import plotly as plotly
import pandas as pd
import json
import plotly.express as px
from flask import Flask, render_template, request
params = {
  "engine": "google_scholar_author",
  "author_id": "qc6CJjYAAAAJ",
  "api_key": "7ee2182e807e2c42b0c5d02b1f88d8f31607a3f62a9af3e21126d8921ed2672f"
}

search = GoogleSearch(params)
results = search.get_dict()
cited_by = results["cited_by"]['graph']
print((cited_by))


def notdash(data=cited_by):
  df = pd.DataFrame(data)
  fig = px.bar(df, x='year', y='citations',
               barmode='group')
  graphJSON = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
  print(graphJSON)
  return graphJSON

#notdash()