class Analysis:
    def __init__(self, DB_name):
        self.DB_name = DB_name


