# Kagiso Yako
# 31/08/2022
# Class for executing high level sqlite instructions and database interaction and management.

import sqlite3
from SQL_queries import SQL_queries

class DB_manager:
    def __init__(self, DB_name):
        self.DB_name = DB_name

    def researchers_per_inst(self):
        conn = sqlite3.connect(self.DB_name)
        cursor = conn.cursor()
        cursor.execute("SELECT Institution, count(Institution) FROM Researchers group by institution;")
        count_inst = cursor.fetchall()
        institutions = []
        frequencies = []
        for i in range(len(count_inst)):
            institutions.append(count_inst[i][0])
            frequencies.append(count_inst[i][1])
        return institutions , frequencies

    def researchers_per_rating(self):
        ratings = ["A", "B", "C", "P", "Y"]
        frequencies = []
        conn = sqlite3.connect(self.DB_name)
        cursor = conn.cursor()

        for rating in ratings:
            query = SQL_queries.count_records("Researchers", single_column="Rating") + " WHERE "
            str_rating = "\""+rating+"\""
            query += SQL_queries.compare_to_other("Rating", str_rating, "=")
            cursor.execute(query)
            frequencies.append(cursor.fetchone()[0])

        return ratings, frequencies
    
    def researcher_dist_by_inst(self):
    
        conn = sqlite3.connect(self.DB_name)
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT Institution FROM Researchers")
        inst_column = cursor.fetchall()
        #print_data(inst_column)
        institutions = []
        rating_count = []
        for item in inst_column:
    
            inst = item[0]
            #print(inst)
            #print()

            query = "SELECT  Rating, Count(Rating), Institution FROM Researchers "
            query += "WHERE Institution = '" + inst
            query += "' GROUP BY Rating"
    
            #print(query)
            cursor2 = conn.cursor()
            cursor2.execute(query)
            rating_frequency = cursor2.fetchall()
    
            #print_data(rating_frequency)
             
            d = {}
            for i in rating_frequency:
                rating = i[0]
                frequency = i[1]
                d[rating] = frequency
                
            institutions.append(inst)
            rating_count.append(d)
    
        return institutions , rating_count
    
    def researchers_per_specialization(self):
    
        conn = sqlite3.connect(self.DB_name)
        cursor = conn.cursor()
        
        AI_fields = [
                     "Machine learning",
                     "Natural language processing",
                     "Knowledge representation and reasoning",
                     "Search methodologies",
                     "Control methods",
                     "Computer vision",
                     "Deep learning",
                     "Artificial intelligence",
                     "Robotics",
                     "Reinforcement learning"
                    ]
    
        field_X = []
        num_researchers_Y =[]
    
        for field in AI_fields:
    
            query = "SELECT Count(Surname) FROM Researchers "
            query += "WHERE Specializations LIKE  '%" + field + "%';"
    
            cursor.execute(query)
            data = cursor.fetchall()
    
            field_X.append(field)
            num_researchers_Y.append(data[0][0])
    
            #print(field)
            #print_data(data[0])
    
        return field_X, num_researchers_Y   
    
    def researcher_dist_by_specialization(self):
    
        conn = sqlite3.connect(self.DB_name)
        cursor = conn.cursor()
    
        AI_fields = [
                     "Machine learning",
                     "Natural language processing",
                     "Knowledge representation and reasoning",
                     "Search methodologies",
                     "Control methods",
                     "Computer vision",
                     "Deep learning",
                     "Artificial intelligence",
                     "Robotics",
                     "Reinforcement learning"
                    ]
        
        topic = []
        rating_distriution = []
    
        for field in AI_fields:
    
    
            #print(inst)
            #print()
    
            query = "SELECT  Rating, Count(Rating) FROM Researchers "
            query += "WHERE Specializations LIKE '%" + field + "%' "
            query += "GROUP BY Rating"
    
            #print(query)
            cursor.execute(query)
            data = cursor.fetchall()
    
            #print(field)
            #print_data(data)
    
            topic.append(field)
            rating_distriution.append(data)
    
    
    
        return  topic, rating_distriution
    
    def speciailization_dist_by_inst(self):
    
        conn = sqlite3.connect(self.DB_name)
        cursor = conn.cursor()
    
        AI_fields = [
                     "Machine learning",
                     "Natural language processing",
                     "Knowledge representation and reasoning",
                     "Search methodologies",
                     "Control methods",
                     "Computer vision",
                     "Deep learning",
                     "Artificial intelligence",
                     "Robotics",
                     "Reinforcement learning"
        ]
        
        topic = []
        specialization_distriution = []
    
        for field in AI_fields:
    
    
            #print(inst)
            #print()
    
            query = "SELECT  Institution, Count(Institution) FROM Researchers "
            query += "WHERE Specializations LIKE '%" + field + "%' "
            query += "GROUP BY Institution"
    
            #print(query)
            cursor.execute(query)
            data = cursor.fetchall()
    
            #print(field)
            #print_data(data)
    
            topic.append(field)
            specialization_distriution.append(data)
    
    
    
        return  topic, specialization_distriution    

